import time
attempt = 0
while attempt in range(3):
    user_name = input("Please enter your username:\n")
    password = input("Please enter your password:\n")

    if user_name == "admin" and password == "abc123":
        print("Welcome back", user_name)
        break
    else:
        print("Incorrect username or password")
        attempt += 1
        if attempt == 2:
            print("You have been locked out for 45 seconds")
            time.sleep(45)
            print("You can try again")
            user_name = input("Please enter your username:\n")
            password = input("Please enter your password:\n")
